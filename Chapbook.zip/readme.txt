License and Notes
Tis typeface is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike License. To view a copy of
this license, visit http://creativecommons.org/licenses/by-nc-sa/2.0/ or send a letter to Creative Commons, 559 Nathan Abbott
Way, Stanford, California 94305, USA.
Note that the license includes the provision �Any of these conditions can be waived if you get permission from the copyright
holder�. You already have my permission to use this font for commercial purposes, such as in a magazine or advertising, and do
not need to ask (though a copy of whatever you used it for would be nice). If you wish to redistribute this font commercially,
including on a website with paid advertising, you must still get my permission to do so and �you must make clear to others the
license terms of this work�.
Fe�rag
e-mail: feorag@antipope.org
http://www.antipope.org/feorag/freestuff/